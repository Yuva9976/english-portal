import React from 'react'
export default function Footer(){
  return (
    <footer className='bg-slate-900 text-slate-200'>
      <div className='container mx-auto px-4 py-8 flex flex-col md:flex-row justify-between'>
        <div>
          <div className='font-bold text-xl'>EnglishLearn</div>
          <p className='text-sm max-w-md'>Practice English with lessons, quizzes and track your progress.</p>
        </div>
        <div className='mt-4 md:mt-0'>
          <div className='font-semibold'>Links</div>
          <ul className='text-sm'>
            <li>Home</li>
            <li>Lessons</li>
            <li>Dashboard</li>
          </ul>
        </div>
      </div>
      <div className='bg-slate-800 text-sm text-center py-3'>© {new Date().getFullYear()} EnglishLearn</div>
    </footer>
  )
}
