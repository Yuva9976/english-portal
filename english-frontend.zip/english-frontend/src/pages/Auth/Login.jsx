import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import apiClient from '../../apiClient'

export default function Login(){
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()

  async function handleSubmit(e){
    e.preventDefault()
    setError('')
    try {
      const res = await apiClient.post('/auth/login', { email, password })
      // expecting token in res.data.token or backend may set cookie
      if (res.data?.token) {
        localStorage.setItem('token', res.data.token)
      }
      navigate('/dashboard')
    } catch (err) {
      console.error(err)
      setError(err?.response?.data?.message || 'Login failed')
    }
  }

  return (
    <div className='max-w-md mx-auto bg-white p-6 rounded-lg shadow'>
      <h2 className='text-2xl font-semibold mb-4'>Login</h2>
      {error && <div className='text-red-600 mb-3'>{error}</div>}
      <form onSubmit={handleSubmit} className='space-y-4'>
        <div>
          <label className='block text-sm'>Email</label>
          <input value={email} onChange={e=>setEmail(e.target.value)} className='w-full mt-1 p-2 border rounded' />
        </div>
        <div>
          <label className='block text-sm'>Password</label>
          <input type='password' value={password} onChange={e=>setPassword(e.target.value)} className='w-full mt-1 p-2 border rounded' />
        </div>
        <button className='w-full py-2 bg-sky-600 text-white rounded'>Login</button>
      </form>
      <div className='text-sm mt-3'>Don't have an account? <a href='/register' className='text-sky-600'>Register</a></div>
    </div>
  )
}
