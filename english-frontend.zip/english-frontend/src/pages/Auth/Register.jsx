import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import apiClient from '../../apiClient'

export default function Register(){
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()

  async function handleSubmit(e){
    e.preventDefault()
    setError('')
    try {
      const res = await apiClient.post('/auth/register', { name, email, password })
      if (res.data?.token) localStorage.setItem('token', res.data.token)
      navigate('/dashboard')
    } catch (err) {
      console.error(err)
      setError(err?.response?.data?.message || 'Registration failed')
    }
  }

  return (
    <div className='max-w-md mx-auto bg-white p-6 rounded-lg shadow'>
      <h2 className='text-2xl font-semibold mb-4'>Register</h2>
      {error && <div className='text-red-600 mb-3'>{error}</div>}
      <form onSubmit={handleSubmit} className='space-y-4'>
        <div>
          <label className='block text-sm'>Name</label>
          <input value={name} onChange={e=>setName(e.target.value)} className='w-full mt-1 p-2 border rounded' />
        </div>
        <div>
          <label className='block text-sm'>Email</label>
          <input value={email} onChange={e=>setEmail(e.target.value)} className='w-full mt-1 p-2 border rounded' />
        </div>
        <div>
          <label className='block text-sm'>Password</label>
          <input type='password' value={password} onChange={e=>setPassword(e.target.value)} className='w-full mt-1 p-2 border rounded' />
        </div>
        <button className='w-full py-2 bg-emerald-600 text-white rounded'>Register</button>
      </form>
      <div className='text-sm mt-3'>Already have account? <a href='/login' className='text-sky-600'>Login</a></div>
    </div>
  )
}
