import React from 'react'
import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <div className="space-y-12">
      {/* HERO */}
      <section className="relative overflow-hidden rounded-lg">
        <div className="bg-gradient-to-r from-indigo-600 via-sky-500 to-emerald-400 text-white py-20">
          <div className="container mx-auto px-6 md:px-12 flex flex-col-reverse md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <h1 className="text-3xl md:text-5xl font-extrabold leading-tight">
                Learn English confidently — <span className="text-yellow-300">practice</span>, <span className="text-yellow-300">speak</span>, and <span className="text-yellow-300">grow</span>.
              </h1>
              <p className="mt-6 text-sky-100 max-w-xl">
                Bite-sized lessons, interactive quizzes, and progress tracking to help you speak naturally.
                Start from basics or level up with advanced lessons and real-world conversations.
              </p>
              <div className="mt-8 flex gap-3">
                <Link to="/lessons" className="inline-block bg-white text-slate-900 px-6 py-3 rounded-lg font-semibold shadow">
                  Start Learning
                </Link>
                <Link to="/register" className="inline-block px-6 py-3 border border-white/40 rounded-lg">
                  Join Free
                </Link>
              </div>
              <div className="mt-6 flex flex-wrap gap-4 text-sm text-sky-100">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 bg-white/10 rounded flex items-center justify-center font-semibold">A1</div>
                  <div>Beginner to Advanced</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 bg-white/10 rounded flex items-center justify-center font-semibold">Quiz</div>
                  <div>Interactive Quizzes</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 bg-white/10 rounded flex items-center justify-center font-semibold">Track</div>
                  <div>Progress Dashboard</div>
                </div>
              </div>
            </div>

            <div className="md:w-1/2 flex justify-center">
              <div className="w-full max-w-md bg-white/10 rounded-xl p-4 backdrop-blur-sm">
                <img src="https://images.unsplash.com/photo-1503676260728-1c00da094a0b?q=80&w=800&auto=format&fit=crop" alt="students" className="rounded-lg shadow-lg" />
                <div className="mt-4 text-sm text-sky-100">
                  <strong>Real students:</strong> Improve fluency with lessons and practice speaking in a safe environment.
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="container mx-auto px-6 md:px-12">
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-white rounded-lg p-6 shadow">
            <h3 className="font-semibold text-lg">Structured Curriculum</h3>
            <p className="mt-2 text-sm text-slate-600">Short lessons that build on each other so learning is simple and reliable.</p>
          </div>
          <div className="bg-white rounded-lg p-6 shadow">
            <h3 className="font-semibold text-lg">Interactive Quizzes</h3>
            <p className="mt-2 text-sm text-slate-600">Immediate feedback and explanations to help you understand mistakes.</p>
          </div>
          <div className="bg-white rounded-lg p-6 shadow">
            <h3 className="font-semibold text-lg">Personal Dashboard</h3>
            <p className="mt-2 text-sm text-slate-600">Track progress, points, and completed lessons at a glance.</p>
          </div>
        </div>
      </section>

      {/* LESSONS PREVIEW */}
      <section className="container mx-auto px-6 md:px-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold">Featured Lessons</h2>
          <Link to="/lessons" className="text-sky-600">See all lessons</Link>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-white rounded-lg overflow-hidden shadow hover:shadow-lg transition">
            <img src="https://images.unsplash.com/photo-1529070538774-1843cb3265df?q=80&w=800&auto=format&fit=crop" alt="lesson" className="w-full h-44 object-cover"/>
            <div className="p-4">
              <h4 className="font-semibold">Everyday Conversations</h4>
              <p className="mt-2 text-sm text-slate-600">Practice dialogues and useful phrases for daily life.</p>
            </div>
          </div>

          <div className="bg-white rounded-lg overflow-hidden shadow hover:shadow-lg transition">
            <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=800&auto=format&fit=crop" alt="lesson" className="w-full h-44 object-cover"/>
            <div className="p-4">
              <h4 className="font-semibold">Grammar Essentials</h4>
              <p className="mt-2 text-sm text-slate-600">Clear explanations and practice to strengthen foundations.</p>
            </div>
          </div>

          <div className="bg-white rounded-lg overflow-hidden shadow hover:shadow-lg transition">
            <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=800&auto=format&fit=crop" alt="lesson" className="w-full h-44 object-cover"/>
            <div className="p-4">
              <h4 className="font-semibold">Listening Practice</h4>
              <p className="mt-2 text-sm text-slate-600">Short audio tracks + comprehension questions.</p>
            </div>
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="bg-slate-50 py-12">
        <div className="container mx-auto px-6 md:px-12">
          <h3 className="text-xl font-semibold mb-6">What learners say</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow">
              <p className="text-sm text-slate-600">"I finally started speaking confidently after 3 months!"</p>
              <div className="mt-4 font-semibold">— Priya</div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <p className="text-sm text-slate-600">"Lessons are easy to follow and quizzes are fun."</p>
              <div className="mt-4 font-semibold">— Ahmed</div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <p className="text-sm text-slate-600">"Dashboard helped me track my progress day by day."</p>
              <div className="mt-4 font-semibold">— Latha</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto px-6 md:px-12">
        <div className="rounded-lg p-8 bg-gradient-to-r from-emerald-400 to-sky-400 text-white flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h4 className="text-lg font-bold">Ready to improve your English?</h4>
            <p className="mt-2 text-sm">Start with a free lesson and see how quickly you improve.</p>
          </div>
          <div>
            <Link to="/register" className="px-6 py-3 bg-white text-slate-900 rounded-lg font-semibold">Get started — it's free</Link>
          </div>
        </div>
      </section>
    </div>
  )
}
